/*
  jimpic is free software; you can redistribute it and/or modify it and
  it is provided under the terms of version 2 of the GNU General Public
  License as published by the Free Software Foundation; see COPYING.
*/

#ifndef HW_H
#define HW_H

typedef struct {
	/* Necessary pins */
	unsigned int pgm:1;
	unsigned int mclr:1;
	unsigned int clock:1;
	unsigned int data:1;

	/* Other pins, for more capable burners */
	unsigned int power:1;
	unsigned int ready:1;
	unsigned int go:1;
} pins;

#define MS 1000000
#define US 1000
#define NS 1
void hw_sleep(unsigned int ns);

/* Below functions return negative on failure */

/* Initialize the given parallel port, or NULL to search for hardware. */
int hw_init(char *port, int slow, int probe);

/* Set pins according to p */
int hw_set_pins(pins *p);

/* Fill p according to pins */
int hw_get_pins(pins *p);

/* Test the hardware */
int hw_test(void);

#endif
