/*
  jimpic is free software; you can redistribute it and/or modify it and
  it is provided under the terms of version 2 of the GNU General Public
  License as published by the Free Software Foundation; see COPYING.
*/

#ifndef PIC_H
#define PIC_H

#include "hw.h"

enum pic_command_id {
	cmd_load_config = 0,
	cmd_load_program,
	cmd_load_data,
	cmd_inc_addr,
	cmd_read_program,
	cmd_read_data,
	cmd_erase_program,
	cmd_program,
	cmd_bulk_erase_program,
	cmd_bulk_erase_data,
	cmd_bulk_setup_1,
	cmd_bulk_setup_2
};

enum pic_chip {
	chip_16f627 = 0,
	chip_16f627a,
	chip_16f628,
	chip_16f628a,
	chip_16f648a,
	chip_auto
};

extern const char *chip_text[];
extern const int chip_id[];
extern const int chip_maxaddr[];

/* All functions return negative on failure. */

int pic_enter_lvp(void);
int pic_leave_lvp(void);

/* Second parameter optional 
   (pointer if cmd_data_read, or literal if cmd_data_write) */
int pic_command(enum pic_command_id id, ...);

/* Bulk erase program */
int pic_action_erase(int nodata, int writeonly);

/* Bulk erase program, data, config */
int pic_action_erase_all(int chip, int nodata, int writeonly);

/* Test and return ID (location 0x2006) */
int pic_action_test(void);

/* Run PIC (pull /MCLR high, pull PGM high) */
int pic_action_run(void);

/* Stop PIC (pull /MCLR low) */
int pic_action_stop(void);

/* Ensure that buffer contains only valid program and config for this PIC */
int pic_check_buffer(int chip, unsigned char *cbuffer, unsigned char *cdirty);

/* Read PIC and compare to buffer. */
int pic_action_verify(int chip, unsigned char *cbuffer, 
		      unsigned char *cdirty, int nodata);

/* Read program and config from PIC, storing result in buffer */
int pic_action_read(int chip, unsigned char *cbuffer, unsigned char *cdirty);

/* Write program and config to PIC from buffer */
int pic_action_write(int chip, unsigned char *cbuffer,
		     unsigned char *cdirty, int nodata, int writeonly);

#endif
