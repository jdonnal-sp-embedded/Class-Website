/*
  jimpic is free software; you can redistribute it and/or modify it and
  it is provided under the terms of version 2 of the GNU General Public
  License as published by the Free Software Foundation; see COPYING.
*/

#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include "hw.h"

void _outp(unsigned short, unsigned char);
unsigned char _inp(unsigned short);

#define outb(byte,port) _outp((unsigned short)(port),byte)
#define inb(port) _inp((unsigned short)(port))

int base=0;
int slow=0;

/* Compatibility */
int strcasecmp(const char *s1, const char *s2) {
	return stricmp(s1,s2);
}
unsigned int sleep(unsigned int seconds) {
	Sleep(seconds*1000);	
	return 0;
}

__int64 rdtsc_frequency = 0;

void hw_sleep(unsigned int ns) {
	__int64 tsc_start;
	__int64 tsc_now;
	__int64 tsc_diff;
	
	/* Use Windows timer if time too long or no RDTSC. */
	if(slow>0 || ns>(2*MS) || rdtsc_frequency<=0 ||
		QueryPerformanceCounter((LARGE_INTEGER *)&tsc_start)==0) {
		if(slow>=2) {
			Sleep((ns+999999)/10000);
		}
		else {
			Sleep((ns+999999)/1000000);
		}
		return;
	}

	tsc_diff=((rdtsc_frequency*(__int64)ns)+999999999)/(__int64)1000000000;
	do QueryPerformanceCounter((LARGE_INTEGER *)&tsc_now);
	while((tsc_now-tsc_start)<tsc_diff);
}

int hw_init_timer(void) {
	if(slow>0) return 0;
	
	if(QueryPerformanceFrequency((LARGE_INTEGER *)&rdtsc_frequency)==0 ||
		rdtsc_frequency<0) {
		fprintf(stderr,"Processor does not support high resolution "
			"timer; using standard timer.\n");
		rdtsc_frequency=0;
		return 0;
	}
	return 0;
}

int hw_init_port(int p) {
	/* Ensure that the control port is sane, so PS/2 ports are */
	/* placed into output mode */
	outb(0x0F,base+2);
	return 0;
}

int hw_init(char *port, int nslow, int nprobe) {
	OSVERSIONINFO osvi;
	int need_giveio=0;
	HANDLE h;
	int probe[] = { 0x278, 0x378, 0x3bc };
	int i;
	int detected=0;

	slow=nslow;
	if(slow==1)
		printf("Using millisecond delays.\n");
	if(slow>=2)
		printf("Using long millisecond delays.\n");

	osvi.dwOSVersionInfoSize=sizeof(OSVERSIONINFO);
	if(GetVersionEx(&osvi)==0) {
		fprintf(stderr,"Can't get Windows version info!\n");
		return -1;
	}

	if(osvi.dwPlatformId==VER_PLATFORM_WIN32_WINDOWS) {
		printf("Windows 95/98/ME detected.\n");
		need_giveio=0;
	} else if(osvi.dwPlatformId==VER_PLATFORM_WIN32_NT) {
		printf("Windows NT/2K/XP detected.\n");
		need_giveio=1;
	} else {
		printf("Error: unknown version of Windows detected!\n");
		return -1;
	}

	if(need_giveio) {
		h=CreateFile("\\\\.\\giveio", GENERIC_READ, 0, NULL,
			     OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);
		if(h==INVALID_HANDLE_VALUE) {
			fprintf(stderr,"Error: Can't open GIVEIO driver.\n");
			fprintf(stderr,"Your version of Windows requires "
				"that the GIVEIO driver be installed.\n");
			return -1;
		}
		CloseHandle(h);
	}

	if(hw_init_timer()<0) {
		fprintf(stderr,"Can't initialize timer.\n");
		return -1;
	}
	
	if(port!=NULL) 
		base=strtoul(port,NULL,0);
	
	/* Try to open some LPT ports.  Might keep some Windows programs */
	/* from messing with them.. */
	fopen("LPT0","r+");
	fopen("LPT1","r+");
	fopen("LPT2","r+");
	fopen("LPT3","r+");

	if(base==0 && nprobe) {
		port = NULL;
		for(i=0;i<sizeof(probe)/sizeof(*probe);i++) {
			base=probe[i];
			if(hw_init_port(base)<0) return -1;
			if(hw_test()>=0) {
				detected=1;
				break;
			}
		}
	} else {
		if(hw_init_port(base)<0) return -1;
		if(nprobe) {
			if(hw_test()>=0)
				detected=1;
		} else {
			detected=2;
		}
	}

	if(detected==0) {
		fprintf(stderr,"Hardware not detected ");
		if(port==NULL) 
			fprintf(stderr,"(on any port).\n");
		else
			fprintf(stderr,"(on port 0x%03X).\n",base);
		return -1;
	}

	printf("%s hardware at port 0x%03X\n",
	       (detected==1) ? "Detected" : "Assumed", 
	       base);
	return 0;
}

int hw_set_pins(pins *p) {
	unsigned char data=0;

	if(base==0) {
		fprintf(stderr,"bug: called hw_set_pins but base==0!\n");
		return -1;
	}

	data|=(!p->data)<<0;
	data|=(!p->clock)<<1;
	data|=(!p->mclr)<<2;
	data|=(!p->pgm)<<3;
	data|=(p->ready)<<4;
	data|=(p->power)<<5;
	outb(data,base);
	return 0;
}

int hw_get_pins(pins *p) {
	unsigned char data, status;

	if(base==0) {
		fprintf(stderr,"bug: called hw_get_pins but base==0!\n");
		return -1;
	}

	data=inb(base);
	status=inb(base+1);

	p->data=!((status&64)==64);
	p->go=!((status&128)==128);
	p->clock=!((data&2)==2);
	p->mclr=!((data&4)==4);
	p->pgm=!((data&8)==8);
	return 0;
}
