/*
  jimpic is free software; you can redistribute it and/or modify it and
  it is provided under the terms of version 2 of the GNU General Public
  License as published by the Free Software Foundation; see COPYING.
*/

#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include "hw.h"
#include "pic.h"

const char *chip_text[] = { "16F627", "16F627A", "16F628", 
			    "16F628A", "16F648A", "auto" };
const int chip_id[] = { 0x07B0, 0x1040, 0x07C0, 0x1060, 0x1100, -1 };
const int chip_maxaddr[] = { 0x03FF, 0x03FF, 0x07FF, 0x07FF, 0x0FFF, -1 };

/* All timing is handled here.  Timings are from the Microchip
   programming specifications, plus Tpd when necessary 
   which is sufficient delay for a round trip (propagation time
   along cable and any active components along the way; 40ns
   for the cable alone, so 100ns to be safe) */

typedef struct {
	int id;
	unsigned char command;
	enum cmd_dir { cmd_data_none, cmd_data_read,
		       cmd_data_write } dir;
	unsigned int extra_ms;
} pic_command_t;

pic_command_t pic_command_list[] = {
	{ cmd_load_config,		0x00,	cmd_data_write,	0 },
	{ cmd_load_program,		0x02,	cmd_data_write, 0 },
	{ cmd_load_data,		0x03,	cmd_data_write, 0 },
	{ cmd_inc_addr,			0x06,	cmd_data_none,	0 },
	{ cmd_read_program,		0x04,	cmd_data_read,	0 },
	{ cmd_read_data,		0x05, 	cmd_data_read,	0 },
	{ cmd_erase_program,		0x08,	cmd_data_none,	13 }, /* T1 */
	{ cmd_program,			0x18,	cmd_data_none,	8 },  /* T2 */
	{ cmd_bulk_erase_program,	0x09,	cmd_data_none,	0 },
	{ cmd_bulk_erase_data,		0x0B,	cmd_data_none,	0 },
	{ cmd_bulk_setup_1,		0x01,	cmd_data_none, 	0 },
	{ cmd_bulk_setup_2,		0x07,	cmd_data_none,	0 },
	{ -1, 0, cmd_data_none } };	
/* T1: Tera + Tprog */
/* T2: Tprog */

int pic_send_bit(unsigned short bit);
int pic_receive_bit(void);
int pic_send_command(unsigned short cmd);
int pic_send_data(unsigned short data);
int pic_receive_data(void);

int pic_command(enum pic_command_id id, ...)
{
	va_list ap;
	unsigned short d, *p;
	int r;
	int i;

	va_start(ap, id);
	for(i=0;pic_command_list[i].id>=0;i++)
		if(pic_command_list[i].id==id)
			break;
	if(pic_command_list[i].id<0) {
		fprintf(stderr,"bug: invalid argument to pic_command\n");
		return -1;
	}
	switch(pic_command_list[i].dir) {
	case cmd_data_none:
		if(pic_send_command(pic_command_list[i].command)<0)
			return -1;
		if(pic_command_list[i].extra_ms>0)
			hw_sleep(pic_command_list[i].extra_ms*MS);
		return 0;
	case cmd_data_write:
		/* va_arg parameters will get promoted to int */
		d=(unsigned short) va_arg(ap, int);
		if(pic_send_command(pic_command_list[i].command)<0)
			return -1;
		if(pic_send_data(d)<0)
			return -1;
		if(pic_command_list[i].extra_ms>0)
			hw_sleep(pic_command_list[i].extra_ms*MS);
		return 0;
	case cmd_data_read:
		p=va_arg(ap, unsigned short *);
		if(pic_send_command(pic_command_list[i].command)<0)
			return -1;
		if((r=pic_receive_data())<0)
			return -1;
		*p=(unsigned short)r;
		if(pic_command_list[i].id==cmd_read_data)
			*p&=0xff;
		if(pic_command_list[i].extra_ms>0)
			hw_sleep(pic_command_list[i].extra_ms*MS);
		return 0;
	default:
		fprintf(stderr,"bug: unknown cmd format\n");
		return -1;
	}
	fprintf(stderr,"bug: not reached\n");
	return -1;
}

int pic_enter_lvp(void)
{
	pins p;
	p.power=p.ready=1; 
	p.mclr=p.pgm=p.data=p.clock=0;
	if(hw_set_pins(&p)<0) return -1;
	hw_sleep(10*US); /* Tppdp=5us plus time for chip to reset */
	
	p.mclr=p.pgm=1;
	if(hw_set_pins(&p)<0) return -1;
	hw_sleep(5*US); /* Thld0 = 5us */

	return 0;	
}

int pic_leave_lvp(void)
{
	pins p;
	p.power=p.ready=1;
	p.mclr=p.pgm=p.data=p.clock=0;
	hw_sleep(50*US); /* give any previous commands time to settle */
	if(hw_set_pins(&p)<0) return -1;
	return 0;
}

int pic_send_bit(unsigned short bit) 
{
	pins p;
	p.power=p.ready=1;
	p.mclr=p.pgm=1;
	p.clock=1;
	p.data=bit;
	if(hw_set_pins(&p)<0) return -1;
	hw_sleep(100*NS); /* Tset1 = 100 ns */
	p.clock=0;
	if(hw_set_pins(&p)<0) return -1;
	hw_sleep(100*NS); /* Thld1 = 100 ns */
	return 0;
}

/* Returns bit, or negative on failure */
int pic_receive_bit(void)
{
	int ret;
	pins p;
	p.power=p.ready=1;
	p.mclr=p.pgm=1;
	p.clock=1;
	p.data=0;
	if(hw_set_pins(&p)<0) return -1;
	hw_sleep(80*NS + 100*NS); /* Tdly3 = 80 ns + Tpd = 100 ns */
	if(hw_get_pins(&p)<0) return -2;
	ret=p.data;
	p.clock=0;
	if(hw_set_pins(&p)<0) return -3;
	hw_sleep(100*NS); /* Thld1 = 100 ns (actual requirement for
			     clock down to next clock up is unclear) */
	return ret;
}

int pic_send_command(unsigned short cmd)
{
	int i;

	for(i=0;i<6;i++) {
		if(pic_send_bit((unsigned short)(cmd&1))<0) return -1;
		cmd>>=1;
	}
	hw_sleep(1*US); /* Tdly2 = 1 us */
	return 0;
}

int pic_send_data(unsigned short data)
{
	int i;

	if(pic_send_bit(0)<0) return -1;
	for(i=0;i<14;i++,data>>=1)
		if(pic_send_bit((unsigned short)(data&1))<0) return -1;
	if(pic_send_bit(0)<0) return -1;
	return 0;
}

/* Returns data, or negative on failure */
int pic_receive_data(void)
{
	unsigned short data=0;
        int ret;
	int i;

	if(pic_receive_bit()<0) return -1;
	for(i=0;i<14;i++) {
		data>>=1;
		ret=pic_receive_bit();
		if(ret<0) return -1;
		data|=(ret&1)<<13;
	}
	if(pic_receive_bit()<0) return -1;
	return (int)data;
}

/* Bulk erase program and (optinally) data memory; print status and errors */
int pic_action_erase(int nodata, int writeonly) {
	int test;

	if(pic_enter_lvp()<0) {
		fprintf(stderr,"Can't enter LVP mode\n");
		return -1;
	}

	printf("Executing bulk erase of program memory... ");
	fflush(stdout);
	
	if(pic_command(cmd_load_program, 0x3fff)<0 ||
	   pic_command(cmd_bulk_erase_program)<0 ||
	   pic_command(cmd_program)<0) goto bail;

	if(!writeonly) {
		/* Verify it */
		test=0xFFFF;
		if(pic_leave_lvp()<0 ||
		   pic_enter_lvp()<0 ||
		   pic_command(cmd_read_program,&test)<0 ||
		   test!=0x3FFF) {
			printf("\n");
			fprintf(stderr,"Verify error; erase seems to have "
				"failed (read back 0x%04X)\n",test);
			fprintf(stderr,"If code protection is enabled, use "
				"the --erase-all option to remove it.\n");
			pic_leave_lvp();
			return -1;
		}
	}
		
	printf("done\n");

	if(nodata) {
		pic_leave_lvp();
		return 0;
	}

	printf("Executing bulk erase of data memory... ");
	fflush(stdout);
	
	if(pic_leave_lvp()<0 ||
	   pic_enter_lvp()<0 ||
	   pic_command(cmd_load_data, 0x3fff)<0 ||
	   pic_command(cmd_bulk_erase_data)<0 ||
	   pic_command(cmd_program)<0) goto bail;

	if(!writeonly) {
		/* Verify it */
		test=0xFFFF;
		if(pic_leave_lvp()<0 ||
		   pic_enter_lvp()<0 ||
		   pic_command(cmd_read_data,&test)<0 ||
		   test!=0xFF) {
			printf("\n");
			fprintf(stderr,"Verify error; erase seems to have "
				"failed (read back 0x%02X)\n",test);
			fprintf(stderr,"If code protection is enabled, use "
				"the --erase-all option to remove it.\n");
			pic_leave_lvp();
			return -1;
		}
	}

	printf("done\n");
	
	pic_leave_lvp();
	return 0;
	
 bail:
	printf("\n");
	fprintf(stderr,"Bulk erase failed.\n");
	pic_leave_lvp();
	return -1;
}

/* Bulk erase program, data, config; print status and errors */
int pic_action_erase_all(int chip, int nodata, int writeonly) {
	int i;
	int test;
	int seq[]={ cmd_bulk_setup_1, cmd_bulk_setup_2,
		    cmd_erase_program,
		    cmd_bulk_setup_1, cmd_bulk_setup_2 };

	if(chip==chip_16f627a || chip==chip_16f628a || chip==chip_16f648a) {
		/* These chips don't seem to support this!  Grr.. */
		return pic_action_erase(nodata,writeonly);
	}
		

	if(nodata) {
		/* This may clobber data, so don't do it.  Use normal erase. */
		return pic_action_erase(nodata,writeonly);
	}

	if(pic_enter_lvp()<0) {
		fprintf(stderr,"Can't enter LVP mode\n");
		return -1;
	}

	printf("Executing bulk erase of all memory... ");
	fflush(stdout);
	
	if(pic_command(cmd_load_config, 0x3fff)<0) goto bail;
	for(i=0;i<7;i++)
		if(pic_command(cmd_inc_addr)<0) goto bail;
	for(i=0;i<sizeof(seq)/sizeof(*seq);i++)
		if(pic_command(seq[i])<0) goto bail;

	if(!writeonly) {
		/* Verify it */
		test=0xFFFF;
		if(pic_leave_lvp()<0 ||
		   pic_enter_lvp()<0 ||
		   pic_command(cmd_read_program,&test)<0 ||
		   test!=0x3FFF) {
			printf("\n");
			fprintf(stderr,"Verify error; erase seems to have failed "
				"(read back 0x%04X)\n",test);
			pic_leave_lvp();
			return -1;
		}
	}
		
	printf("done\n");

	/* Sometimes this leaves data memory unerased.  Erase that, too. */
	if(pic_leave_lvp()<0 ||
	   pic_enter_lvp()<0 ||
	   pic_command(cmd_load_data, 0x3fff)<0 ||
	   pic_command(cmd_bulk_erase_data)<0 ||
	   pic_command(cmd_program)<0)
		/* ignore */;

	pic_leave_lvp();
	return 0;
	
 bail:
	printf("\n");
	fprintf(stderr,"Bulk erase failed.\n");
	pic_leave_lvp();
	return -1;
}

/* Test PIC and return ID (location 0x2006), or negative on failure */
/* Does not print errors */
int pic_action_test(void) {
	/* To test, read the device ID and config word. 
	   The config word must necessarily be nonzero, since
	   (at very least) the LVP enable bit is set. */
	int i;
	unsigned short config[8];

	if(pic_enter_lvp()<0)
		return -1;

	if(pic_command(cmd_load_config, 0x3fff)<0) goto bail;

	for(i=0;i<8;i++) {
		if(pic_command(cmd_read_program,&config[i])<0)
			goto bail;
		if(pic_command(cmd_inc_addr)<0)
			goto bail;
	}

	if(config[7]==0) {
		fprintf(stderr,"Read null config word.\n");
		goto bail;
	}

	pic_leave_lvp();
	return config[6];

 bail:
	pic_leave_lvp();
	return -2;
}

/* Run PIC (pull /MCLR high, pull PGM high) */
int pic_action_run(void)
{
	pins p;
	p.power=1; p.ready=1; p.mclr=1; p.pgm=0; p.clock=1; p.data=1;
	if(hw_set_pins(&p)<0) {
		fprintf(stderr,"Error running PIC.\n");
		return -1;
	} 
	printf("Started PIC.\n");
	return 0;
}

/* Stop PIC (pull /MCLR low) */
int pic_action_stop(void)
{
	pins p;
	p.power=1; p.ready=1; p.mclr=0; p.pgm=0; p.clock=1; p.data=1;
	if(hw_set_pins(&p)<0) {
		fprintf(stderr,"Error stopping PIC.\n");
		return -1;
	} 
	printf("Stopped PIC.\n");
	return 0;
}

int get_max_address(int chip) {
	return chip_maxaddr[chip];
}

/* Ensure that buffer contains only valid program and config for this PIC */
int pic_check_buffer(int chip, unsigned char *cbuffer, unsigned char *cdirty)
{
	unsigned short *d=(unsigned short *)cdirty;
	int max;
	int i;

	if((max=get_max_address(chip))<0) return -1;

	for(i=max+1;i<0x2000;i++)
		if(d[i]!=0) {
		badloc:
			fprintf(stderr,"Error: HEX file contains data for "
				"memory location 0x%04x\n",i);
			fprintf(stderr,"which is not a valid location for "
				"this PIC.\n");
			return -1;
		}
	for(i=0x2004;i<0x2007;i++)
		if(d[i]!=0) goto badloc;
	for(i=0x2008;i<0x2100;i++)
		if(d[i]!=0) goto badloc;
	for(i=0x2180;i<0x4000;i++)
		if(d[i]!=0) goto badloc;
	return 0;
}

/* Read PIC and compare to buffer. */
int pic_action_verify(int chip, unsigned char *cbuffer, 
		      unsigned char *cdirty, int nodata)
{
	unsigned short *buffer=(unsigned short *)cbuffer;
	unsigned short *dirty=(unsigned short *)cdirty;
	int max;
	int maxdirty;
	int i;
	unsigned short test;

	if((max=get_max_address(chip))<0) return -1;
	
	if(pic_enter_lvp()<0) {
		fprintf(stderr,"Can't enter LVP mode\n");
		return -1;
	}
	
	printf("Verifying program memory... ");
	fflush(stdout);

	maxdirty=0;
	for(i=0;i<=max;i++)
		if(dirty[i]!=0)
			maxdirty=i+1;
	for(i=0;i<maxdirty;i++) {
		if(dirty[i]!=0) {
			if(pic_command(cmd_read_program,&test)<0)
				goto picerror;
			if(test!=buffer[i]) {
				printf("\n");
				fprintf(stderr,"Verify failed: mismatch "
					"at 0x%04X (PIC 0x%04X, HEX 0x%04X)\n",
					i,test,buffer[i]);
				if(test==0) 
					fprintf(stderr,"Chip might be code "
						"protected.\n");
				pic_leave_lvp();
				return -1;
			}
		}
		if(pic_command(cmd_inc_addr)<0)
			goto picerror;
	}
	if(i==maxdirty)
		printf("ok!\n");


	if(nodata) goto do_verify_config;

	printf("Verifying data memory... ");
	fflush(stdout);

	if(pic_leave_lvp()<0 ||
	   pic_enter_lvp()<0)
		goto picerror;

	maxdirty=0x2100;
	for(i=0x2100;i<0x2180;i++)
		if(dirty[i]!=0)
			maxdirty=i+1;
	for(i=0x2100;i<maxdirty;i++) {
		if(dirty[i]!=0) {
			if(pic_command(cmd_read_data,&test)<0)
				goto picerror;
			if(test!=buffer[i]) {
				printf("\n");
				fprintf(stderr,"Verify failed: mismatch "
					"at 0x%04X (PIC 0x%02X, HEX 0x%02X)\n",
					i,test,buffer[i]);
				if(test==0) 
					fprintf(stderr,"Chip might be code "
						"protected.\n");
				pic_leave_lvp();
				return -1;
			}
		}
		if(pic_command(cmd_inc_addr)<0)
			goto picerror;
	}
	if(i==maxdirty)
		printf("ok!\n");

do_verify_config:
	printf("Verifying config memory... ");
	fflush(stdout);

	if(pic_command(cmd_load_config,0x3fff)<0) 
		goto picerror;

	for(i=0x2000;i<0x2008;i++) {
		if((i<0x2004 || i>0x2006) && dirty[i]!=0) {
			if(pic_command(cmd_read_program,&test)<0)
				goto picerror;
			if(test!=buffer[i]) {
				printf("\n");
				fprintf(stderr,"Verify failed: mismatch "
					"at 0x%04X (PIC 0x%04X, HEX 0x%04X)\n",
					i,test,buffer[i]);
				if(test==0) 
					fprintf(stderr,"Chip might be code "
						"protected.\n");
				pic_leave_lvp();
				return -1;
			}
		}
		if(pic_command(cmd_inc_addr)<0)
			goto picerror;
	}
	if(i==0x2008)
		printf("ok!\n");

	pic_leave_lvp();
	return 0;

 picerror:
	printf("\n");
	fprintf(stderr,"Error reading from PIC.\n");
	pic_leave_lvp();
	return -1;
}

/* Read PIC, storing result in buffer */
int pic_action_read(int chip, unsigned char *cbuffer, unsigned char *cdirty)
{
	unsigned short *buffer=(unsigned short *)cbuffer;
	unsigned short *dirty=(unsigned short *)cdirty;
	int max;
	int maxdirty;
	int i;

	if((max=get_max_address(chip))<0) return -1;
	
	if(pic_enter_lvp()<0) {
		fprintf(stderr,"Can't enter LVP mode\n");
		return -1;
	}
	
	printf("Reading program memory... ");
	fflush(stdout);

	for(i=0;i<=max;i++) {
		if(pic_command(cmd_read_program,&buffer[i])<0)
			goto picerror;
		dirty[i]=-1;
		if(pic_command(cmd_inc_addr)<0)
			goto picerror;
	}
	/* Trim the dirty down to the last non-0x3FFF byte */
       	maxdirty=-1;
	for(i=0;i<=max;i++) {
		if(buffer[i]!=0x3fff)
			maxdirty=i;
	}
	for(i=maxdirty+1;i<=max;i++)
		dirty[i]=0;
	printf("ok!\n");
	if(maxdirty==-1)
		printf("Warning: PIC appears to be blank\n");

	printf("Reading data memory... ");
	fflush(stdout);
	
	if(pic_leave_lvp()<0 ||
	   pic_enter_lvp()<0) 
		goto picerror;

	for(i=0x2100;i<0x2180;i++) {
		if(pic_command(cmd_read_data,&buffer[i])<0)
			goto picerror;
		dirty[i]=-1;
		if(pic_command(cmd_inc_addr)<0)
			goto picerror;
	}
	/* Trim the dirty down to the last non-0x00FF byte */
       	maxdirty=0x2100-1;
	for(i=0x2100;i<0x2180;i++) {
		if(buffer[i]!=0x00ff)
			maxdirty=i;
	}
	for(i=maxdirty+1;i<0x2180;i++)
		dirty[i]=0;
	printf("ok!\n");

	printf("Reading config memory... ");
	fflush(stdout);

	if(pic_command(cmd_load_config,0x3fff)<0) 
		goto picerror;

	for(i=0x2000;i<0x2008;i++) {
		if(i<0x2004 || i>0x2006) {
			if(pic_command(cmd_read_program,&buffer[i])<0)
				goto picerror;
			if(i>=0x2004 || buffer[i]!=0x3fff)
				dirty[i]=-1;
		}
		if(pic_command(cmd_inc_addr)<0)
			goto picerror;
	}
	printf("ok!\n");

	pic_leave_lvp();
	return 0;

 picerror:
	printf("\n");
	fprintf(stderr,"Error reading from PIC.\n");
	pic_leave_lvp();
	return -1;
}

/* Write program and config to PIC from buffer */
int pic_action_write(int chip, unsigned char *cbuffer, 
		     unsigned char *cdirty, int nodata, int writeonly)
{
	unsigned short *buffer=(unsigned short *)cbuffer;
	unsigned short *dirty=(unsigned short *)cdirty;
	int max;
	int maxdirty;
	int i;
	int try;
	unsigned short test;

	if((max=get_max_address(chip))<0) return -1;
	
	if(pic_enter_lvp()<0) {
		fprintf(stderr,"Can't enter LVP mode\n");
		return -1;
	}
	
	printf("Writing program memory... ");
	fflush(stdout);
	
	maxdirty=0;
	for(i=0;i<=max;i++)
		if(dirty[i]!=0)
			maxdirty=i+1;
	for(i=0;i<maxdirty;i++) {
		if(dirty[i]!=0) {
			test=0xffff;
			for(try=4;try>0;try--) {
				if(pic_command(cmd_load_program,buffer[i])<0 ||
				   pic_command(cmd_erase_program)<0)
					goto picerror;
				if(writeonly) break;
				if(pic_command(cmd_read_program,&test)<0)
					goto picerror;
				if(test==buffer[i])
					break;
				printf("\nWarning: failure at location 0x%04X,"
				       " trying again... ",i);
				fflush(stdout);
			}
			if(try==0) {
				printf("\n");
				fprintf(stderr,"Error burning PIC at "
					"location 0x%04X.\n",i);
				if(test==0) 
					fprintf(stderr,"Chip might be code "
						"protected.\n");
				pic_leave_lvp();
				return -1;
			}
		}
		if(pic_command(cmd_inc_addr)<0)
			goto picerror;
	}
	if(i==maxdirty)
		printf("ok!\n");
	
	if(nodata) goto do_write_config;

	printf("Writing data memory... ");
	fflush(stdout);

	if(pic_leave_lvp()<0 ||
	   pic_enter_lvp()<0)
		goto picerror;
	
	maxdirty=0x2100;
	for(i=0x2100;i<0x2180;i++)
		if(dirty[i]!=0)
			maxdirty=i+1;
	for(i=0x2100;i<maxdirty;i++) {
		if(dirty[i]!=0) {
			test=0xffff;
			for(try=4;try>0;try--) {
				if(pic_command(cmd_load_data,
					       buffer[i]&0xff)<0 ||
				   pic_command(cmd_erase_program)<0)
					goto picerror;
				if(writeonly)
					break;
				if(pic_command(cmd_read_data,&test)<0)
					goto picerror;
				if(test==(buffer[i]&0xff))
					break;
				printf("\nWarning: failure at location 0x%04X,"
				       " trying again... ",i);
				fflush(stdout);
			}
			if(try==0) {
				printf("\n");
				fprintf(stderr,"Error burning PIC at "
					"location 0x%04X.\n",i);
				if(test==0) 
					fprintf(stderr,"Chip might be code "
						"protected.\n");
				pic_leave_lvp();
				return -1;
			}
		}
		if(pic_command(cmd_inc_addr)<0)
			goto picerror;
	}
	if(i==maxdirty)
		printf("ok!\n");

do_write_config:
	printf("Writing config memory... ");
	fflush(stdout);

	if(pic_command(cmd_load_config,0x3fff)<0) 
		goto picerror;

	for(i=0x2000;i<0x2008;i++) {
		if((i<0x2004 || i>0x2006) && dirty[i]!=0) {
			test=0xffff;
			for(try=4;try>0;try--) {
				if(pic_command(cmd_load_program,buffer[i])<0 ||
				   pic_command(cmd_erase_program)<0)
					goto picerror;
				if(writeonly)
					break;
				if(pic_command(cmd_read_program,&test)<0)
					goto picerror;
				if(test==buffer[i])
					break;
				printf("\nWarning: failure at location 0x%04X,"
				       " trying again... ",i);
				fflush(stdout);
			}
			if(try==0) {
				printf("\n");
				fprintf(stderr,"Error burning PIC at "
					"location 0x%04X\n.",i);
				pic_leave_lvp();
				return -1;
			}
		}
		if(pic_command(cmd_inc_addr)<0)
			goto picerror;
	}
	if(i==0x2008)
		printf("ok!\n");

	pic_leave_lvp();
	return 0;

 picerror:
	printf("\n");
	fprintf(stderr,"Error writing to PIC.\n");
	pic_leave_lvp();
	return -1;
}
