/*
  jimpic is free software; you can redistribute it and/or modify it and
  it is provided under the terms of version 2 of the GNU General Public
  License as published by the Free Software Foundation; see COPYING.
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int char_to_hex(char c) {
	if(c>='0' && c<='9') 
		return c-'0';
	else if(c>='a' && c<='f')
		return c-'a'+10;
	else if(c>='A' && c<='F')
		return c-'A'+10;
	else 
		return -1;
}

int hex(char *p) {
	int a,b;
	a=char_to_hex(p[0]);
	if(a<0) return -1;
	b=char_to_hex(p[1]);
	if(b<0) return -1;
	return((int)((unsigned char)a*16+(unsigned char)b));
}

/* buffer must be 64k.  dirty, if not null, has entries set to 0xff
   iff corresponding byte in buffer was touched.  Returns negative
   on error. */
int read_hex(FILE *in, unsigned char *buffer, unsigned char *dirty)
{
	char s[256*2+20];
	int bytecount;
	unsigned char bytes[256];
	unsigned short address;
	unsigned char checksum;
	int line=0;
	int i;
	int a,b;
	int type;

	while(!feof(in)) {
		s[0]=0;
		fgets(s,sizeof(s),in);
		line++;
		if(feof(in)) break;
		if(s[0]=='\n') continue;
		if(s[0]!=':' || strlen(s)<10) {
			fprintf(stderr,"Error: input doesn't appear to be "
				"a HEX file (at line %d)\n",line);
			return -1;
		}
		if(s[strlen(s)-1]=='\n')
			s[strlen(s)-1]='\0';
		else {
			if(feof(in)) {
				fprintf(stderr,"Warning: input HEX file "
					"missing newline; may "
					"be truncated (at line %d)\n",line);
			} else {
				fprintf(stderr,"Error: line too long in "
					"HEX file (at line %d)\n",line);
				return -1;
			}
		}
		if(s[strlen(s)-1]=='\r') s[strlen(s)-1]='\0';

		/* Now process valid line */
		if((bytecount=hex(s+1))<0) {
		badinput:
			fprintf(stderr,"Error: invalid HEX file "
				"(at line %d)\n",line);
			return -1;
		}

		if((a=hex(s+3))<0 || (b=hex(s+5))<0) goto badinput;
		address=(unsigned short)a*256+(unsigned short)b;

		if((type=hex(s+7))<0) goto badinput;

		checksum=bytecount+a+b+type;

		for(i=0;i<bytecount;i++) {
			a=hex(s+9+2*i);
			if(a<0) goto badinput;
			bytes[i]=a;
			checksum+=bytes[i];
		}

		checksum=-checksum;
		if(hex(s+9+2*i)!=checksum) {
			fprintf(stderr,"Error: checksum mismatch (expected "
				"0x%02X) in HEX file "
				"(at line %d)\n",checksum,line);
			return -1;
		}

		if(type==1) 
			return 0;
		else if(type!=0) {
			if(type==0x04 && bytecount==0x02) {
				/* Ignore this one silenty; not sure why
				   so many programs include it. */
			} else {
				fprintf(stderr,"Warning: ignoring HEX record "
					"type %02x (at line %d)\n",type,line);
			}
			continue;
		}

		if((int)address+bytecount>65536) {
			fprintf(stderr,"Error: data runs off end of buffer "
				"in HEX file (at line %d)\n",line);
			return -1;
		}

		for(i=0;i<bytecount;i++) {
			buffer[address+i]=bytes[i];
			if(dirty!=NULL)
				dirty[address+i]=0xff;
		}
	}
	return 0;
}

int write_hex(FILE *out, unsigned char *buffer, unsigned char *dirty)
{
	int p=0;
	int q;
	unsigned char checksum;
	int tmp;

	while(p<65536) {
		if(dirty!=NULL && dirty[p]!= 0xff) {
			p++;
			continue;
		}

		/* Find ending byte (noninclusive) for this run */
		for(q=p+1;q<65536 && dirty[q]==0xff && (q-p)<16;q++)
			;

		if(fprintf(out,":%02X%04X00",q-p,p)!=9) {
		badwrite:
			fprintf(stderr,"Error writing HEX file.\n");
			return -1;
		}

		checksum=(q-p)+((p&0xff00)>>8)+(p&0xff);

		for(;p<q;p++) {
			tmp=buffer[p];
			if(fprintf(out,"%02X",tmp)!=2)
				goto badwrite;
			checksum+=buffer[p];
		}

		tmp=(int)(unsigned char)-checksum;
		if(fprintf(out,"%02X\n",tmp)!=3) goto badwrite;
	}
	if(fprintf(out,":00000001FF\n")!=12) goto badwrite;
	return 0;
}
