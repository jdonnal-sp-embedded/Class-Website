/*
  jimpic is free software; you can redistribute it and/or modify it and
  it is provided under the terms of version 2 of the GNU General Public
  License as published by the Free Software Foundation; see COPYING.
*/

#include <stdio.h>
#include <stdlib.h>
#include "hw.h"

int hw_test(void) {
	pins test;
	test.pgm=0; 
	test.mclr=0;
	test.clock=0;
	test.data=0;
	if(hw_set_pins(&test)<0) return -1;
	hw_sleep(100*NS); /* Tpd = 100ns */
	if(hw_get_pins(&test)<0) return -2;
	if(test.data!=0) 
		return -3;
	test.data=1;
	if(hw_set_pins(&test)<0) return -4;
	hw_sleep(100*NS); /* Tpd = 100ns */
	if(hw_get_pins(&test)<0) return -5;
	if(test.data==0)
		return -6;
	return 0;
}
