/*
  jimpic is free software; you can redistribute it and/or modify it and
  it is provided under the terms of version 2 of the GNU General Public
  License as published by the Free Software Foundation; see COPYING.
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "pic.h"
#include "opt.h"
#include "hex.h"

#define VERSION "1.9"

struct options opt[] = {
	{ 'p', "port", "port", "specify the port address (default: auto)" },
	{ 'c', "chip", "name", "specify chip (default: auto)" },
	{ 'b', "burn", "file", "\"fbp\" mode: erase all, burn, and verify" },
	{ 'R', "run", NULL, "run the PIC (set /MCLR high, PGM low)" },
	{ 'S', "stop", NULL, "stop the PIC (set /MCLR low)" },
	{ 'r', "read", "file", "read all memory, save in file" },
	{ 'w', "write", "file", "write all memory from file" },
	{ 'e', "erase", NULL, "erase program and data memory" },
	{ 'E', "erase-all", NULL, "erase all memory, clear code protection" },
	{ 'v', "verify", "file", "verify all memory from file" },
	{ 't', "test", NULL, "only test the hardware" },
	{ 's', "slow", NULL, "use slower delays" },
	{ 'n', "nodata", NULL, "never touch the data memory" },
	{ 'W', "writeonly", NULL, "never read from the PIC" },
	{ 'V', "version", NULL, "show program version and exit" },
	{ 'P', "power", NULL, "control power line on PIC burner" },
	{ 'G', "go", NULL, "wait for signal on port before doing anything" },
	{ 'h', "help", NULL, "this help" },
	{ 0, NULL, NULL, NULL }
};

int main(int argc, char *argv[])
{
	int optind;
	char *optarg;
	char c;
	int i;
	char *port=NULL;
	int chip = chip_auto;
	int tmpchip;
	int slow=0;
	int nodata=0;
	int writeonly=0;
	int power=0;
	int gosignal=0;
	char *filename=NULL;
	enum { action_read, action_write, action_erase, 
	       action_erase_all, action_verify, action_fbp,
	       action_run, action_stop,
	       action_test, action_none} action = action_none;
	unsigned char buffer[65536], dirty[65536];
	FILE *f;
	FILE *help=stderr;
	int ret;

	opt_init(&optind);
	while((c=opt_parse(argc,argv,&optind,&optarg,opt))!=0) {
		switch(c) {
		case 'p':
			port=optarg;
			break;
		case 'c':
			chip=chip_auto;
			for(i=0;i<chip_auto;i++) {
				if(strcasecmp(optarg,chip_text[i])==0)
					chip=i;
			}
			if(chip==chip_auto) {
				fprintf(stderr,"Unknown chip '%s'\n",optarg);
				fprintf(stderr,"Known chips:\n");
				for(i=0; i<chip_auto; i++)
					fprintf(stderr,"\t%s\n",chip_text[i]);
				fprintf(stderr,"\n");
				goto printhelp;
			}
			break;			
		case 'b':
			if(action!=action_none) goto printaction;
			action=action_fbp;
			filename=optarg;
			break;
		case 'R':
			if(action!=action_none) goto printaction;
			action=action_run;
			break;
		case 'S':
			if(action!=action_none) goto printaction;
			action=action_stop;
			break;
		case 'r':
			if(action!=action_none) goto printaction;
			action=action_read;
			filename=optarg;
			break;
		case 'w':
			if(action!=action_none) goto printaction;
			action=action_write;
			filename=optarg;
			break;
		case 'e':
			if(action!=action_none) goto printaction;
			action=action_erase;
			break;
		case 'E':
			if(action!=action_none) goto printaction;
			action=action_erase_all;
			break;
		case 'v':
			if(action!=action_none) goto printaction;
			action=action_verify;
			filename=optarg;
			break;
		case 'V':
			printf("jimpic " VERSION "\n");
			printf("Written by Jim Paris <jim@jtan.com>.\n");
			printf("jimpic is free software; you can redistribute it ");
			printf("and/or modify it and\nit is provided under the terms ");
			printf("of version 2 of the GNU General Public\nLicense as ");
			printf("published by the Free Software Foundation.\n");
			return 0;
			break;
		case 't': 
			if(action!=action_none) goto printaction;
			action=action_test;
			break;
		case 's':
			slow++;
			break;
		case 'n':
			nodata++;
			break;
		case 'W':
			writeonly++;
			break;
		case 'P':
			power++;
			break;
		case 'G':
			gosignal++;
			break;
		printaction:
			fprintf(stderr,"Error: only one action may be "
				"specified at a time.\n\n");
			goto printhelp;
		case 'h':
			help=stdout;
		default:
		printhelp:
			fprintf(help,"Usage: %s [options]\n\n",*argv);
			opt_help(opt,help);
			return 1;
		}
	}
	if(optind<argc) {
		fprintf(stderr,"Error: too many arguments (%s)\n\n",
			argv[optind]);
		goto printhelp;
	}

	if(action==action_none) {
		fprintf(stderr,"Error: no action specified!\n\n");
		goto printhelp;
	}

	if(writeonly && !
	   (action==action_write || action==action_erase ||
	    action==action_erase_all || action==action_test ||
	    action==action_run || action==action_stop)) {
		fprintf(stderr,"Error: in write-only mode, the only valid "
			"operations are -w, -e, -E, -t, -R, -S.\n\n");
		goto printhelp;
	}

	if(writeonly && chip==chip_auto) {
		fprintf(stderr,"Error: in write-only mode, you must specify "
			"the chip with -c.\n\n");
		goto printhelp;
	}

	if(power && port==NULL) {
		fprintf(stderr,"Error: port must be specified when "
			"using --power\n");
		return 1;
	}

	/* This will drop setuid privs here, if under Linux */
	if(hw_init(port, slow, !power) < 0)  /* Only probe if power=0 */
		return 1; /* Don't need to print error; hw_init does it */

	if(action==action_write || 
	   action==action_verify || 
	   action==action_fbp) {
		if(strcmp(filename,"-")==0) {
			f=stdin;
		} else { 
			if((f=fopen(filename,"r"))==NULL) {
				perror(filename);
				return 1;
			}
		}
		memset(dirty,0,sizeof(dirty));
		if(read_hex(f,buffer,dirty)<0) {
			fprintf(stderr,"Error reading hex file %s\n",filename);
			return 1;
		}
		printf("Loaded %s\n",filename);
	}

	if(gosignal) {
		pins p;
		printf("Waiting for GO signal from burner...\n");
		p.power=p.mclr=p.pgm=p.data=p.clock=0;
		p.ready=1;
		if(hw_set_pins(&p)<0) {
			fprintf(stderr,"Can't set pins.\n");
			return -1;
		}
		for(;;) {
			if(hw_get_pins(&p)<0) {
				fprintf(stderr,"Can't get pins.\n");
				return -1;
			}
			if(!p.go) break;  /* Wait for line to go low */
			hw_sleep(100*US);
		}
	}

	if(power) {
		pins p;
		printf("PIC burner power on.\n");
		p.power=p.ready=1;
		p.mclr=p.pgm=p.data=p.clock=0;
		if(hw_set_pins(&p)<0) {
			fprintf(stderr,"Can't set pins.\n");
			return -1;
		}
		hw_sleep(500*MS);  /* give power time to settle */
	}

	if(action==action_run)
		return pic_action_run();

	if(action==action_stop)
		return pic_action_stop();

	if(writeonly) {
		printf("Not reading from the chip.\n");
		printf("Assuming chip %s\n",chip_text[chip]);
	} else {
		/* Test PIC and get chip ID */
		if((ret=pic_action_test())<0) {
			if(action==action_test) {
				fprintf(stderr,"Chip detection failed; checking"
					" hardware more carefully\n");
				goto run_more_tests;
			}
			fprintf(stderr,"Error testing PIC; chip may be "
				"missing or faulty, or try the --test option\n"
				"to test the hardware.\n");
			return 1;
		}
		
		/* Handle chip selection */
		tmpchip = chip_auto;
		for(i=0; i<chip_auto; i++) {
			if((ret & 0x03FE0) == chip_id[i]) {
				tmpchip = i;
				printf("Detected chip %s\n",chip_text[i]);
			}
		}

		if(chip==chip_auto) chip=tmpchip;
		
		if(chip!=tmpchip) {
			printf("Warning: forcing chip to %s, as requested\n",
			       chip_text[chip]);
		}
		if(chip==chip_auto) {
			printf("Warning: unknown chip (id 0x%04x) detected; "
			       "assuming %s\n", ret, chip_text[chip_16f628a]);
			chip=chip_16f628a;
		}
	}
	
	if(nodata) {
		printf("Not touching the data memory.\n");
	}
		
	/* Do the action here */
	switch(action) {
	case action_read:
		if(strcmp(filename,"-")==0) {
			f=stdout;
		} else {
			if((f=fopen(filename,"w"))==NULL) {
				perror(filename);
				return 1;
			}
		}
		memset(buffer,0,sizeof(buffer));
		memset(dirty,0,sizeof(dirty));
		if(pic_action_read(chip,buffer,dirty)<0 ||
		   write_hex(f,buffer,dirty)<0)
			return 1;
		return 0;
	case action_verify:
		if(pic_check_buffer(chip,buffer,dirty)<0 ||
		   pic_action_verify(chip,buffer,dirty,nodata)<0)
			return 1;
		return 0;
	case action_fbp:
		if(pic_check_buffer(chip,buffer,dirty)<0 ||
		   pic_action_erase_all(chip,nodata,writeonly)<0 ||
		   pic_action_write(chip,buffer,dirty,nodata,writeonly)<0 ||
		   pic_action_verify(chip,buffer,dirty,nodata)<0)
			return 1;
		return 0;
	case action_write:
		if(pic_check_buffer(chip,buffer,dirty)<0 ||
		   pic_action_write(chip,buffer,dirty,nodata,writeonly)<0)
			return 1;
		return 0;	   
	case action_test:
	run_more_tests:		
		printf("Testing port access (10 seconds)...\n");
		{
			unsigned int sleep(unsigned int);
			pins p;
			p.power=p.ready=1;
			p.mclr=p.pgm=p.data=p.clock=0;
			if(hw_set_pins(&p)<0) {
			test_no_set:
				fprintf(stderr,"Can't set pins.\n");
				return -1;
			}
			sleep(5); /* seconds; this isn't hw_sleep */
			p.mclr=p.pgm=p.data=p.clock=1;
			if(hw_get_pins(&p)<0) {
			test_no_get:
				fprintf(stderr,"Can't get pins.\n");
			}
			if(p.mclr==1 || p.pgm==1 || p.clock==1) {
			test_no_go:
				fprintf(stderr,"It appears that some other "
					"program is messing with the\n"
					"parallel port.  Please ensure "
					"that all other programs attempting\n"
					"to access the port are closed or "
					"disabled.  This includes printer\n"
					"utilities, external drive detection "
					"utilities, other PIC programmers, "
					"etc.\n");
				return -1;
			}
			p.mclr=p.pgm=p.data=p.clock=1;
			if(hw_set_pins(&p)<0) goto test_no_set;
			sleep(5);
			p.mclr=p.pgm=p.data=p.clock=0;
			if(hw_get_pins(&p)<0) goto test_no_get;
			if(p.mclr==0 || p.pgm==0 || p.clock==0) 
				goto test_no_go;
		}

		printf("Running more hardware tests...\n");
		for(i=25001;i>0;i--) {
			if(hw_test()<0) {
				fprintf(stderr,
					"Failed on test %d/25000.\n",25001-i);
				return 1;
			}
		}
		printf("Tests passed; hardware should be okay.\n");
		return 0;
	case action_erase:
		return (pic_action_erase(nodata,writeonly)<0)?1:0;
	case action_erase_all:
		return (pic_action_erase_all(chip,nodata,writeonly)<0)?1:0;
	case action_none:
	default:
		fprintf(stderr,"bug: Unknown action\n");
		return 1;
	}

	fprintf(stderr,"bug: shouldn't get here\n");
	return 1;
}
