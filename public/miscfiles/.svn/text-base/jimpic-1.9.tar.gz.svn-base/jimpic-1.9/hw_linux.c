/*
  jimpic is free software; you can redistribute it and/or modify it and
  it is provided under the terms of version 2 of the GNU General Public
  License as published by the Free Software Foundation; see COPYING.
*/

#include <time.h>
#include <sched.h>
#include <sys/time.h>
#include <sys/types.h>
#include <sys/unistd.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/io.h>
#include <signal.h>
#include <errno.h>
#include "hw.h"

int base=0;
int slow=0;

void reset_pins(void)
{
	pins p;
	p.power=p.ready=p.mclr=p.pgm=p.data=p.clock=0;
	hw_set_pins(&p);
}

void exit_sig(int s)
{
	/* So atexit stuff gets called */
	exit(1);
}

void hw_sleep(unsigned int ns) {
	if(slow<=0) {
#if _POSIX_TIMERS > 0
		/* This can get much closer to the short delays,
		   especially on 2.6 kernels */
		struct timespec start, now;
		unsigned int diff;
		clock_gettime(CLOCK_REALTIME, &start);
		do {
			clock_gettime(CLOCK_REALTIME, &now);
			diff = ((now.tv_sec - start.tv_sec) * 1000000000)
				+ (now.tv_nsec - start.tv_nsec);
		} while(diff < ns);
#else
		struct timespec req, rem;
		req.tv_sec = ns/1000000000;
		req.tv_nsec = ns%1000000000;
		while(nanosleep(&req,&rem)<0 && errno==EINTR) {
			req.tv_sec=rem.tv_sec;
			req.tv_nsec=rem.tv_nsec;
		}
#endif
	} else if(slow==1) {
		/* Sleep in millisecond intervals */
		usleep((ns+999999)/1000);
	} else {
		/* Sleep 100 times as long */
		usleep((ns+999999)/10);
	}
}

int hw_init_timer(void) {
#if _POSIX_TIMERS > 0
	/* Don't need higher priority */
	printf("Using POSIX timers\n");
#else
	struct sched_param p;

	if((p.sched_priority=sched_get_priority_min(SCHED_RR))<0) {
		fprintf(stderr,"Can't get minimum scheduling priority.\n");
		return -1;
	}

	if(sched_setscheduler(0,SCHED_RR,&p)<0) {
		fprintf(stderr,"Can't set scheduling priority.\n");
		return -1;
	}
#endif

	return 0;
}

int hw_get_perm(int p) {
	if(ioperm(p,3,1)<0) {
		fprintf(stderr,"Error getting I/O permissions.\n");
		return -1;
	}
	return 0;
}

int hw_drop_perm(int p) {
	ioperm(p,3,0);
	return 0;
}

int hw_init_port(int p) {
	/* Ensure that the control port is sane, so PS/2 ports are */
	/* placed into output mode */
	outb(0x0F,base+2);
	return 0;
}

int hw_init(char *port, int nslow, int nprobe) {
	int probe[] = { 0x278, 0x378, 0x3bc };
	int i;
	int detected=0;

	slow=nslow;

	if(slow==1)
		printf("Using millisecond delays.\n");
	if(slow>=2)
		printf("Using long millisecond delays.\n");
		
	if(geteuid()!=0) {
		fprintf(stderr,"Can't initialize hardware.\n");
		fprintf(stderr,"Please run this program as root");
		fprintf(stderr," or make it setuid root.\n");
		return -1;
	}

	if(port!=NULL) 
		base=strtoul(port,NULL,0);

	if(hw_init_timer()<0) {
		fprintf(stderr,"Can't increase timer resolution; "
			"continuing anyway.\n");
	}

	if(base==0 && nprobe) {
		port = NULL;
		for(i=0;i<sizeof(probe)/sizeof(*probe);i++) {
			base=probe[i];
			if(hw_get_perm(base)<0) return -1;
			if(hw_init_port(base)<0) return -1;
			if(hw_test()>=0) {
				detected=1;
				break;
			}
			hw_drop_perm(base);
		}
	} else {
		if(hw_get_perm(base)<0) return -1;
		if(hw_init_port(base)<0) return -1;
		if(nprobe) {
			if(hw_test()<0)
				hw_drop_perm(base);
			else
				detected = 1;
		} else {
			detected = 2;
		}
	}

	if(detected==0) {
		fprintf(stderr,"Hardware not detected ");
		if(port==NULL) 
			fprintf(stderr,"(on any port).\n");
		else
			fprintf(stderr,"(on port 0x%03X).\n",base);
		setuid(getuid());
		return -1;
	}

	printf("%s hardware at port 0x%03X\n",
	       (detected==1) ? "Detected" : "Assumed", 
	       base);
	setuid(getuid());

	atexit(reset_pins);
	signal(SIGINT, exit_sig);
	signal(SIGTERM, exit_sig);
	return 0;
}

int hw_set_pins(pins *p) {
	unsigned char data=0;

	if(base==0) return -1;

	data|=(!p->data)<<0;
	data|=(!p->clock)<<1;
	data|=(!p->mclr)<<2;
	data|=(!p->pgm)<<3;
	data|=(p->ready)<<4;
	data|=(p->power)<<5;
	outb(data,base);
	return 0;
}

int hw_get_pins(pins *p) {
	unsigned char data, status;

	if(base==0) return -1;

	data=inb(base);
	status=inb(base+1);

	p->data=!((status&64)==64);
	p->go=!((status&128)==128);
	p->clock=!((data&2)==2);
	p->mclr=!((data&4)==4);
	p->pgm=!((data&8)==8);
	return 0;
}
