/*
  jimpic is free software; you can redistribute it and/or modify it and
  it is provided under the terms of version 2 of the GNU General Public
  License as published by the Free Software Foundation; see COPYING.
*/

#ifndef HEX_H
#define HEX_H

/* buffer must be 64k.  dirty, if not null, has entries set to 0xff
   iff corresponding byte in buffer was touched.  Returns negative
   on error. */
int read_hex(FILE *in, unsigned char *buffer, unsigned char *dirty);

/* buffer must be 64k.  dirty, if not null, has entries set to 0xff
   iff corresponding byte in buffer should be written.  Returns negative
   on error. */
int write_hex(FILE *out, unsigned char *buffer, unsigned char *dirty);

#endif
